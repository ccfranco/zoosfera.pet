<!DOCTYPE html>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900|Quicksand:400,700|Questrial" rel="stylesheet" />
<link href="<?php echo base_url()?>css/default.css" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo base_url()?>fonts/fonts.css" rel="stylesheet" type="text/css" media="all" />
<!--PIE DE PAGINA-->
<div id="footer">
	<div class="container">
		<div class="fbox1">
		<span class="icon icon-map-marker"></span>
			<span>Alcalde Sergio Prieto Nieto Nº 452.
			<br />Viña del Mar</span>
		</div>
		<div class="fbox1">
			<span class="icon icon-phone"></span>
			<span>
				Telefono:  32 260 3325 - 32 260 3322 .
			</span>
		</div>
		<div class="fbox1">
			<span class="icon icon-cogs"></span>
			<span> <a href="http://fonoaudiologia.uv.cl">fonoaudiologia.uv.cl</a> </span>
		</div>
	</div>
</div>

</body>
</html>
?>